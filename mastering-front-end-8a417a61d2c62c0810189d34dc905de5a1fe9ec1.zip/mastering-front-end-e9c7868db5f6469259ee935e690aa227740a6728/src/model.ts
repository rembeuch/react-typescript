export interface MessagesInt {
  id: number,
  message: string | undefined,
  date: number
}